package com.example.myfirstprogramhit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView result;
    String num1 = "";
    boolean isZero = true;
    String op = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        result = findViewById(R.id.textViewResult);


    }
    public void ButtonFunctionNumber(View view)
    {


            Button b = (Button) view;
            if(isZero)
            { result.setText(b.getText());
                isZero = false; }
            else
                result.append(b.getText());


    }


    public void ButtonClear(View view) {

        result.setText("0");
        isZero = true;

    }

    public void buttonOperator(View view) {

        Button b = (Button) view;
        switch(view.getId()) {

            case R.id.buttonPlus:
                op = "+";
                num1 = result.getText().toString();
                result.setText("");
                break;
            case R.id.buttonMinus:
                op = "-";
                num1 = result.getText().toString();
                result.setText("");
                break;
            case R.id.buttonMulti:
                op = "*";
                num1 = result.getText().toString();
                result.setText("");
                break;
            case R.id.buttonDivide:
                op = "/";
                num1 = result.getText().toString();
                result.setText("");
        }
    }


    public void buttonEquals(View view) {
        String num2 = result.getText().toString();
        double res = 0.0;
        String Res = "";
        switch (op)
        {
            case"+":
                res = Double.parseDouble(num1) + Double.parseDouble(num2);
                break;
            case"-":
                res = Double.parseDouble(num1) - Double.parseDouble(num2);
                break;
            case"/":
                res = Double.parseDouble(num1) / Double.parseDouble(num2);
                break;
            case"*":
                res = Double.parseDouble(num1) * Double.parseDouble(num2);
                break;
        }
        Res = res+"";
        if(Res.endsWith(".0")) {
            Res = Res.replace(".0", "");
        }
        result.setText(Res);
        isZero = true;
    }
}